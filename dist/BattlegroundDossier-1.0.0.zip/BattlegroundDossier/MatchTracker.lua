local B = BattlegroundDossier
B.Match = {}
local M = B.Match
function M:Initialize()
    B.Combat:Initialize()
    EVENT_MANAGER:RegisterForEvent(B.name, EVENT_BATTLEGROUND_STATE_CHANGED, function(_, previous, current) self:State(previous, current) end)
    EVENT_MANAGER:RegisterForEvent(B.name, EVENT_BATTLEGROUND_SCOREBOARD_UPDATED, function() self:Roster(); if self.pending then self:TryCapture() end end)
    EVENT_MANAGER:RegisterForEvent(B.name, EVENT_PLAYER_ACTIVATED, function() self:Activated() end)
    EVENT_MANAGER:RegisterForEvent(B.name, EVENT_PLAYER_DEACTIVATED, function() if self.pending then self:TryCapture() end end)
    self:Activated()
end
function M:Stop()
    EVENT_MANAGER:UnregisterForUpdate(B.name .. "Final")
    EVENT_MANAGER:UnregisterForUpdate(B.name .. "Recognition")
    self.pending = nil
    B.Combat:SetActive(false)
end
function M:Activated()
    if not B.API:Call("IsActiveWorldBattleground") then
        self:Stop(); self.session = nil; B.db.active = nil
        return
    end
    self:EnsureSession()
    local state = B.API:Call("GetCurrentBattlegroundState")
    if state == BATTLEGROUND_STATE_FINISHED then self:Finish() else self:Roster(); B.Combat:SetActive(state == BATTLEGROUND_STATE_RUNNING) end
end
function M:EnsureSession(force)
    local map = B.API:Call("GetCurrentBattlegroundId")
    if not map or map <= 0 then return end
    local world = B.API:Call("GetWorldName") or "unknown"
    local saved = B.db.active
    if not force and type(saved) == "table" and saved.mapId == map and saved.world == world
        and type(saved.id) == "string" and type(saved.startedAt) == "number" and B.Now() - saved.startedAt < 21600 then
        self.session = saved
        saved.observations = type(saved.observations) == "table" and saved.observations or {}
        for id, abilities in pairs(saved.observations) do saved.observations[id] = B.Storage:RepairAbilities(abilities) end
        saved.seenRoster = type(saved.seenRoster) == "table" and saved.seenRoster or {}
    else
        self:Stop()
        self.session = B.Storage:NewSession(map, world)
        B.Debug("New match session " .. self.session.id)
    end
    return self.session
end
function M:State(previous, current)
    if current == BATTLEGROUND_STATE_NONE then
        self:Stop(); self.session = nil; B.db.active = nil; return
    end
    if not B.API:Call("IsActiveWorldBattleground") then return end
    local force = previous == BATTLEGROUND_STATE_FINISHED and current ~= BATTLEGROUND_STATE_FINISHED
    self:EnsureSession(force)
    B.Debug("State " .. tostring(previous) .. " -> " .. tostring(current))
    if current == BATTLEGROUND_STATE_FINISHED then self:Finish()
    else
        -- POSTROUND never commits. Observations span rounds within the same session.
        self:Roster()
        B.Combat:SetActive(current == BATTLEGROUND_STATE_RUNNING)
        if current == BATTLEGROUND_STATE_RUNNING then
            EVENT_MANAGER:UnregisterForUpdate(B.name .. "Recognition")
            EVENT_MANAGER:RegisterForUpdate(B.name .. "Recognition", 4000, function()
                EVENT_MANAGER:UnregisterForUpdate(B.name .. "Recognition"); self:Roster(); self:Notify()
            end)
        end
    end
end
function M:Roster()
    if not self.session or self.session.finalized then return end
    B.Combat:RefreshRoster(self.session, B.API:Roster(B.API:Call("GetCurrentBattlegroundRoundIndex")))
end
function M:Notify()
    if not self.session or self.session.notified or not B.db.settings.notifications then return end
    local familiar, seen = 0, {}
    for _, p in ipairs(B.Combat.roster) do
        local id = B.Identity(p, self.session.world)
        if id and not seen[id] and not p.isLocal and B.Players:Get(p, self.session.world) then familiar = familiar + 1; seen[id] = true end
    end
    if familiar > 0 then B.Say(familiar .. " Familiar Players Detected"); self.session.notified = true end
end
function M:Finish()
    if not self.session or self.session.finalized or self.pending then return end
    B.Combat:SetActive(false)
    self.session.finishedAt = self.session.finishedAt or B.Now()
    self.pending = { started = GetFrameTimeMilliseconds(), samples = 0 }
    EVENT_MANAGER:RegisterForUpdate(B.name .. "Final", 1000, function() self:TryCapture() end)
    self:TryCapture()
end
function M:TryCapture()
    local pending, session = self.pending, self.session
    if not pending or not session then return end
    if B.API:Call("GetCurrentBattlegroundState") ~= BATTLEGROUND_STATE_FINISHED then self:Stop(); return end
    local now = GetFrameTimeMilliseconds()
    local snapshot, reason = B.API:Snapshot(session)
    if snapshot then
        local fingerprint = B.API:Fingerprint(snapshot)
        if fingerprint ~= pending.fingerprint then
            pending.fingerprint, pending.stableSince, pending.samples = fingerprint, now, 1
        else pending.samples = pending.samples + 1 end
        if pending.samples >= 3 and now - pending.stableSince >= 3000 then
            local saved = B.Storage:Commit(snapshot)
            session.finalized = true
            self:Stop()
            if saved then
                B.Debug("Final scoreboard saved: " .. #snapshot.players .. " participants")
                if B.db.settings.autoOpen and not B.API:Call("IsUnitInCombat", "player") then B.UI:OpenMatch(snapshot) end
            end
            return
        end
    else
        pending.fingerprint, pending.samples = nil, 0
        B.Debug("Waiting for final scoreboard: " .. tostring(reason))
    end
    if now - pending.started >= 30000 then
        self:Stop()
        session.captureFailed = true
        B.Say("Final scoreboard did not stabilize within 30 seconds; match was not saved.")
    end
end
