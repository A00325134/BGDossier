-- Adapter verified against esoui/esoui live ESOUIDocumentation.txt, API 101051.
-- Optional calls return nil rather than manufacturing a zero statistic.
local B = BattlegroundDossier
B.API = {}
local A = B.API
function A:Call(name, ...)
    local fn = _G[name]
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c, d = pcall(fn, ...)
    if ok then return a, b, c, d end
    if not self.errors then self.errors = {} end
    if not self.errors[name] then B.Debug("API unavailable: " .. name); self.errors[name] = true end
end
A.scoreTypes = {
    kills = "KILL", deaths = "DEATH", assists = "ASSISTS", damage = "DAMAGE_DONE", healing = "HEALING_DONE", score = "SCORE",
    damageTaken = "DAMAGE_TAKEN", shieldsGranted = "DAMAGE_SHIELDS_GRANTED", buffsGranted = "BUFFS_GRANTED",
    debuffsGranted = "DEBUFFS_GRANTED", flagsCaptured = "FLAG_CAPTURED", flagCarriedTime = "FLAG_CARRIED_TIME",
    captureDefensePoints = "CAPTURE_DEFENSE_POINTS", killedAttacker = "CAPTURE_KILLED_ATTACKER",
    killedDefender = "CAPTURE_KILLED_DEFENDER", damagedFlagCarrier = "DAMAGED_FLAG_CARRIER",
    healedFlagCarrier = "HEALED_FLAG_CARRIER", healingDefenders = "HEALING_DEFENDERS",
    killedFlagCarrier = "KILLED_FLAG_CARRIER", killStreak = "KILL_STREAK",
}
function A:ObjectiveType(mode)
    if mode == BATTLEGROUND_GAME_TYPE_DEATHMATCH then return "damageTaken", "Damage taken (native Deathmatch objective column)" end
    if mode == BATTLEGROUND_GAME_TYPE_MURDERBALL then return "flagCarriedTime", "Ball carry time (seconds)" end
    if mode == BATTLEGROUND_GAME_TYPE_CAPTURE_THE_FLAG or mode == BATTLEGROUND_GAME_TYPE_KING_OF_THE_HILL
        or mode == BATTLEGROUND_GAME_TYPE_DOMINATION or mode == BATTLEGROUND_GAME_TYPE_CRAZY_KING then
        return "flagsCaptured", "Flags / objectives captured"
    end
end
function A:ModeName(mode)
    if mode and GetString then
        local ok, result = pcall(GetString, "SI_BATTLEGROUNDGAMETYPE", mode)
        if ok and result ~= "" then return result end
    end
    return "Unknown mode"
end
function A:TeamName(team)
    return self:Call("GetBattlegroundTeamName", team) or ("Team " .. tostring(team))
end
function A:AbilityCategory(abilityId)
    -- Resolve only client-known progression metadata. Proc/tick IDs often have none.
    local hasProgression, progression = self:Call("GetAbilityProgressionXPInfoFromAbilityId", abilityId)
    if hasProgression and progression then
        local skillType = self:Call("GetSkillAbilityIndicesFromProgressionIndex", progression)
        if skillType and skillType == SKILL_TYPE_CLASS then return "Class abilities" end
        if skillType and skillType == SKILL_TYPE_WEAPON then return "Weapon abilities" end
        if skillType and (skillType == SKILL_TYPE_GUILD or skillType == SKILL_TYPE_WORLD) then return "Guild / world abilities" end
    end
    return "Other observed effects"
end
function A:Roster(round)
    local rows = {}
    local count = self:Call("GetNumScoreboardEntries", round)
    if type(count) ~= "number" or count < 0 or count > 100 then return rows end
    for i = 1, count do
        local character, account, team, isLocal = self:Call("GetScoreboardEntryInfo", i, round)
        if B.Normalize(character) or B.Normalize(account) then
            rows[#rows + 1] = { index = i, character = character, account = account, team = team,
                    isLocal = isLocal == true, roundIndex = round, classId = self:Call("GetScoreboardEntryClassId", i, round) }
        end
    end
    return rows
end
function A:Snapshot(session)
    if self:Call("GetCurrentBattlegroundState") ~= BATTLEGROUND_STATE_FINISHED then return nil, "not finished" end
    local round = self:Call("GetCurrentBattlegroundRoundIndex")
    if type(round) ~= "number" or round < 1 then return nil, "round unavailable" end
    local hasRounds = self:Call("DoesBattlegroundHaveRounds", session.mapId) == true
    local mode = self:Call("GetCurrentBattlegroundGameType", round)
    local m = { id = session.id, world = session.world, mapId = session.mapId, startedAt = session.startedAt,
        finishedAt = session.finishedAt, localCharacter = session.localCharacter, roundIndex = round, hasRounds = hasRounds,
        mode = mode, modeName = self:ModeName(mode), map = self:Call("GetBattlegroundName", session.mapId),
        teams = {}, players = {}, rounds = {}, apiVersion = self:Call("GetAPIVersion"),
        competitive = self:Call("DoesCurrentBattlegroundImpactMMR"), teamCapacity = self:Call("GetBattlegroundTeamSize", session.mapId) }
    -- Union round rosters so early leavers are not lost when they are absent from the last round.
    -- The cumulative function is called with each entry's own round/index, as in the native UI.
    local rosterByIdentity = {}
    for r = hasRounds and 1 or round, math.min(round, 20) do
        local thisRound = {}
        for _, p in ipairs(self:Roster(r)) do
            local id = B.Identity(p, m.world)
            if id then
                if thisRound[id] then return nil, "duplicate round identity" end
                thisRound[id] = true
                rosterByIdentity[id] = p
            end
        end
    end
    for _, p in pairs(rosterByIdentity) do m.players[#m.players + 1] = p end
    if #m.players == 0 then return nil, "empty scoreboard" end
    local teamCount = self:Call("GetBattlegroundNumTeams", session.mapId)
    if type(teamCount) ~= "number" or teamCount < 2 or teamCount > 10 then return nil, "teams unavailable" end
    m.teamCount = teamCount
    for i = 1, teamCount do
        local team = self:Call("GetBattlegroundTeamByIndex", session.mapId, i)
        if not team then return nil, "team identity unavailable" end
        local result = B.Result(self:Call("GetBattlegroundResultForTeam", team))
        if result == "Unresolved" then return nil, "team result pending" end
        m.teams[team] = { name = self:TeamName(team), result = result,
            score = hasRounds and self:Call("GetCurrentBattlegroundRoundsWonByTeam", team)
                or self:Call("GetCurrentBattlegroundScore", round, team) }
    end
    local objectiveKey, objectiveLabel = self:ObjectiveType(mode)
    m.objectiveLabel = objectiveLabel
    local scoreFn = hasRounds and "GetBattlegroundCumulativeScoreForScoreboardEntryByType" or "GetScoreboardEntryScoreByType"
    local seen = {}
    for _, p in ipairs(m.players) do
        local entryRound = p.roundIndex
        if not m.teams[p.team] then return nil, "player team pending" end
        local identity = B.Identity(p, m.world)
        if not identity or seen[identity] then return nil, "ambiguous roster" end
        seen[identity] = true
        if p.isLocal then
            if m.localTeam then return nil, "multiple local entries" end
            m.localTeam, m.localPlayerId = p.team, identity
        end
        for key, suffix in pairs(self.scoreTypes) do
            local constant = _G["SCORE_TRACKER_TYPE_" .. suffix]
            if constant ~= nil then
                local v = self:Call(scoreFn, p.index, constant, entryRound)
                if type(v) == "number" and v >= 0 then p[key] = v end
            end
        end
        if p.score == nil and p.kills == nil and p.damage == nil then return nil, "player statistics pending" end
        -- A mixed-mode multi-round aggregate has no meaningful single objective unit.
        if not hasRounds and objectiveKey then p.objective = p[objectiveKey] end
        p.medals = {}
        if hasRounds and type(GenerateCumulativeMedalInfoForScoreboardEntry) == "function" then
            local ok = pcall(GenerateCumulativeMedalInfoForScoreboardEntry, p.index, entryRound)
            if ok then
                local last
                for _ = 1, 100 do
                    local id = self:Call("GetNextBattlegroundCumulativeMedalId", last)
                    if not id or id == last then break end
                    local count = self:Call("GetBattlegroundCumulativeNumEarnedMedalsById", id)
                    if type(count) == "number" and count > 0 then p.medals[id] = { name = self:Call("GetMedalName", id), count = count } end
                    last = id
                end
            end
        elseif not hasRounds then
            local n = self:Call("GetBattlegroundNumUsedMedals", session.mapId) or 0
            for medal = 1, math.min(n, 100) do
                local id = self:Call("GetBattlegroundMedalIdByIndex", session.mapId, medal)
                if id then
                    local count = self:Call("GetScoreboardEntryNumEarnedMedalsById", p.index, id, entryRound)
                    if type(count) == "number" and count > 0 then
                        p.medals[id] = { name = self:Call("GetMedalName", id), count = count }
                    end
                end
            end
        end
        p.livesRemaining = self:Call("GetScoreboardEntryNumLivesRemaining", p.index, entryRound)
        p.abilities = B.Copy(session.observations[identity] or {})
        p.index = nil
    end
    if not m.localTeam then return nil, "local entry pending" end
    m.outcome = m.teams[m.localTeam].result
    m.participantCount = #m.players
    m.scoreLabel = hasRounds and "Rounds won" or "Team score"
    m.winningTeams = {}
    local rank, localScore, scoresAvailable = 1, m.teams[m.localTeam].score, true
    for team, t in pairs(m.teams) do
        if t.result == "Win" then m.winningTeams[#m.winningTeams + 1] = team end
        if type(t.score) ~= "number" then scoresAvailable = false end
        if type(localScore) == "number" and type(t.score) == "number" and t.score > localScore then rank = rank + 1 end
    end
    if type(localScore) == "number" and scoresAvailable then m.placement = rank end
    for r = 1, math.min(round, 20) do
        local row = { mode = self:Call("GetCurrentBattlegroundGameType", r), scores = {} }
        for team in pairs(m.teams) do row.scores[team] = self:Call("GetCurrentBattlegroundScore", r, team) end
        m.rounds[r] = row
    end
    for id in pairs(session.seenRoster) do if not seen[id] then m.rosterMayBeIncomplete = true end end
    return m
end
function A:Fingerprint(m)
    local rows = {}
    for _, p in ipairs(m.players) do
        local parts = { "identity=" .. B.Identity(p, m.world), "team=" .. tostring(p.team), "class=" .. tostring(p.classId) }
        for _, key in ipairs(B.metrics) do parts[#parts + 1] = key .. "=" .. tostring(p[key]) end
        for key in pairs(self.scoreTypes) do parts[#parts + 1] = key .. "=" .. tostring(p[key]) end
        table.sort(parts, function(a, b) return tostring(a) < tostring(b) end)
        rows[#rows + 1] = table.concat(parts, "/")
    end
    table.sort(rows)
    local teams = {}; for id, t in pairs(m.teams) do teams[#teams + 1] = tostring(id) .. ":" .. t.result .. ":" .. tostring(t.score) end
    table.sort(teams)
    return table.concat(teams, "|") .. "#" .. table.concat(rows, "|")
end
