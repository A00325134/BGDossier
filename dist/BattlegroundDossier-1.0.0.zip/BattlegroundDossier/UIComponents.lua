local B = BattlegroundDossier
B.Controls = { serial = 0 }
local C = B.Controls
function C:New(parent, kind, template)
    self.serial = self.serial + 1
    local name = B.name .. "Control" .. self.serial
    if template then return WINDOW_MANAGER:CreateControlFromVirtual(name, parent, template) end
    return WINDOW_MANAGER:CreateControl(name, parent, kind)
end
function C:Backdrop(parent)
    local c = self:New(parent, CT_BACKDROP)
    c:SetAnchorFill(parent)
    c:SetCenterColor(0.065, 0.06, 0.055, 0.97)
    c:SetEdgeColor(0.48, 0.37, 0.22, 0.9)
    c:SetEdgeTexture("", 1, 1, 1, 0)
    return c
end
function C:Label(parent, text, x, y, width, height, font)
    local c = self:New(parent, CT_LABEL)
    c:SetAnchor(TOPLEFT, parent, TOPLEFT, x, y)
    c:SetDimensions(width, height or 28)
    c:SetFont(font or "ZoFontGame")
    c:SetColor(0.86, 0.83, 0.76, 1)
    c:SetText(text or "")
    return c
end
function C:Button(parent, text, x, y, width, callback)
    local c = self:New(parent, CT_BUTTON)
    c:SetAnchor(TOPLEFT, parent, TOPLEFT, x, y)
    c:SetDimensions(width, 30)
    c:SetFont("ZoFontGameBold")
    c:SetNormalFontColor(0.78, 0.65, 0.42, 1)
    c:SetMouseOverFontColor(1, 0.9, 0.65, 1)
    c:SetPressedFontColor(1, 1, 1, 1)
    c:SetText(text)
    c:SetHandler("OnClicked", callback)
    return c
end
function C:Tooltip(control, text)
    control:SetMouseEnabled(true)
    control:SetHandler("OnMouseEnter", function(c)
        InitializeTooltip(InformationTooltip, c, BOTTOM, 0, -6)
        SetTooltipText(InformationTooltip, text)
    end)
    control:SetHandler("OnMouseExit", function() ClearTooltip(InformationTooltip) end)
end
function C:Search(parent, x, y, width, callback)
    local bg = self:New(parent, CT_CONTROL)
    bg:SetAnchor(TOPLEFT, parent, TOPLEFT, x, y); bg:SetDimensions(width, 30)
    self:Backdrop(bg)
    local edit = self:New(bg, CT_EDITBOX)
    edit:SetAnchor(TOPLEFT, bg, TOPLEFT, 8, 3); edit:SetDimensions(width - 16, 26)
    edit:SetFont("ZoFontGame"); edit:SetMaxInputChars(100)
    edit:SetHandler("OnTextChanged", function(c) callback(c:GetText()) end)
    edit:SetHandler("OnEscape", function(c) c:LoseFocus() end)
    edit:SetHandler("OnEnter", function(c) c:LoseFocus() end)
    return edit
end
