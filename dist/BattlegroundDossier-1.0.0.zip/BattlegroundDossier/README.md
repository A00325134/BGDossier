# Battleground Dossier

An independent Elder Scrolls Online addon for saved Battleground scoreboards, player encounters, comparisons and observed combat abilities. No libraries, companion software, network access or BGSessionTracker dependency are needed in game.

Version 1.0.0 targets **ESO API 101051 (Update 51)**. The API surface was checked against the ESOUI `live` documentation and native scoreboard source. **This release has not been tested in a running ESO client.** Treat it as an installable release candidate until the in-game checklist below passes. Offline tests cannot establish server event ordering, combat visibility or visual layout.

## Installation

1. Extract the release ZIP into `Documents\Elder Scrolls Online\live\AddOns\`. The result must be `AddOns\BattlegroundDossier\BattlegroundDossier.txt`, with the Lua files beside it. Documents may be redirected to OneDrive on some systems.
2. Alternatively, copy this project's manifest and ten Lua files into an addon folder named **BattlegroundDossier**, using that exact name. Do not copy the project as a nested `BGDossier\BattlegroundDossier` folder.
3. Restart ESO or return to character selection. Enable **Battleground Dossier** in Add-Ons. On a newer client API, check the compatibility notes before allowing an out-of-date addon.
4. Enter a character and type `/bgd`. No dependencies need enabling.

ESO writes `SavedVariables\BattlegroundDossierSavedVariables.lua` when logging out or reloading the UI. Account-wide settings, histories and statistics are shared by your characters; player identity keys include the megaserver. Every saved match identifies the participating local character. As with other addons, a client crash before ESO writes SavedVariables can lose the current session's changes.

## Using the interface

`MATCHES` opens saved history. Select a match for its scoreboard. Click any table heading to sort, or click the filter button to cycle all players, your team, opposing teams and familiar players. Missing values appear as **—** and sort last. Team borders identify teams; **★** marks you and **◆** marks someone encountered before that match. Hover names for full character/account identity and headings for explanations.

Click a player's name to expand their dossier directly below the row. It includes available statistics, team averages, shares, lifetime encounters, retained match links, scoreboard medals, extra scoreboard counters, and observed abilities. Choose **Select A** and **Select B** on any two dossiers, or **Compare with me**, to display a comparison above the table. Differences are A minus B; no overall skill rating is calculated. K/D is unavailable for zero deaths rather than being presented as infinity.

`PLAYERS` searches account names and all retained character aliases. Open a profile to see lifetime team results, character/class observations, maximum recorded totals, historical abilities and links to retained matches. Lifetime totals include subsequently recorded matches when inspecting an older dossier; its “encounters before this match” marker is frozen at capture time.

`STATISTICS` provides lifetime W/L/D totals, win rate, descriptive record totals, frequent opponents/teammates, and recent averages. Recent trends compare the last ten retained matches with the preceding ten; sample sizes and game modes may differ. Maximum totals, including deaths, are records rather than assessments of skill.

`SETTINGS` controls automatic opening, recognition notifications, combat recording, debug logging, scale, storage limits and recognition thresholds. Drag the window to reposition it. Close it with **×**, Escape or `/bgd`. It hides when the local player enters combat and does not capture keyboard input until you focus search. Native scrollbars and mouse wheel navigate long contents; history/player lists use pages of 40 to bound UI control creation. The search field is debounced and applies to player identities in the selected view.

History filters cycle through results, competitive matches (authoritative MMR-impact flag), Big Team Battles (reported team capacity at least six), and recorded game modes. Formats are displayed using the API's team count, team capacity and actual recorded participants; the addon does not assume a fixed number of participants. “Competitive” is not inferred solely from a four-player team size.

## Commands

| Command | Action |
| --- | --- |
| `/bgd` | Toggle window |
| `/bgd last` | Latest saved match |
| `/bgd history` | Match history |
| `/bgd players` | Player database |
| `/bgd stats` | Statistics |
| `/bgd settings` | Settings |
| `/bgd help` | Command help |
| `/bgd debug on` / `/bgd debug off` | Lifecycle diagnostics |
| `/bgd reset` | Arm destructive history reset for 30 seconds |
| `/bgd reset confirm` | Confirm armed reset; settings are retained |

Only `/bgd` is registered. BGSessionTracker files and commands are untouched.

## How match recording works

The tracker starts or resumes a session on Battleground activation/state changes. `BATTLEGROUND_STATE_FINISHED` is the only capture trigger. `POSTROUND` does **not** finish a match. Combat recording pauses between rounds. A match's ID is a local session token (world, timestamp and saved sequence), not a claimed server match ID. The token and capture marker survive `/reloadui`; saved IDs are checked before encounter/statistic aggregation.

At completion, the addon reads the final scoreboard every second for up to 30 seconds and reacts to scoreboard-update events. It requires nonempty player records, at least some statistics for each player, one local entry, known team identities, and authoritative final results for every team. A snapshot must remain unchanged for at least three seconds across at least three reads before it is saved. Missing optional numeric fields remain absent, not zero. A stable, partially populated roster cannot always be distinguished from the game's actual final roster; the addon never invents missing participants.

For multi-round Battlegrounds, it enumerates round rosters and uses the native cumulative-statistics API with each participant's most recent round/index. This retains earlier-round leavers where those round entries remain available. Team aggregate scores are **rounds won**; per-round team scores are saved separately. Mixed-round objective totals are unavailable because different modes use different units. Single-round objective columns mirror the native UI: damage taken for Deathmatch, ball-carry seconds for Murderball, captures for the other verified objective modes. The detailed dossier also shows the other exposed scoreboard counters.

Team results use `GetBattlegroundResultForTeam`, including true ties. Placement is competition rank by final score/round wins, shared by tied scores; it is not a fabricated official placement field. Three-team results against another player count a win only when your team won and their team lost, a loss only in the reverse case, and a draw only when both teams have authoritative ties. Two losing teams have an **unresolved** result against each other.

If data never stabilizes, capture stops with a chat message. Leaving before completion does not produce a completed-match record. Leaving before the stabilization window finishes can also lose the record; there is no speculative save of preliminary data. State/session data is kept only while inside a Battleground and is expired after six hours. Rejoining after being outside the Battleground starts a new observation session, since no verified permanent match ID is exposed.

## Player recognition

Account display names (`@name`) are preferred, normalized and scoped to the megaserver. Different characters merge only when their scoreboard explicitly reports the same account. Without an account, the exact normalized character name forms a limited-confidence profile. Only grammatical suffixes, color markup and surrounding whitespace are stripped; there is no fuzzy name matching. Missing-account character profiles are **not** automatically merged into later account profiles. Account renames cannot be reliably linked; recycled character names can affect character-only history.

The default frequent-player threshold is five encounters in the relevant relationship. Labels describe encounter frequency, never skill. An optional one-time match-start chat notice counts reliably identified profiles from the available scoreboard. It can miss players whose identity arrives late; it does not query hidden enemy identities. Your own local entry is excluded from the familiar-player database.

## What observed abilities mean

Only supported damage/healing combat results visible to your local client are summarized. Source names must match exactly one current roster identity. Pet/companion, unknown, ambiguous and error sources are discarded. Unit IDs from combat events are **not** treated as account identities. Name caches are reset on roster changes. Events arriving before the roster identifies a source are discarded rather than retroactively guessed.

An ability record contains its ID, supplied name, first/last observed timestamps, relevant event count and observed damage/healing values when available. **Event counts are not cast counts.** Damage-over-time and healing-over-time ticks count as events. Healing values are observed event values, not a claim of effective healing after overheal. Client-known progression metadata may identify class, weapon or guild/world categories; unknown tick/proc IDs remain “Other observed effects.” Subclassed abilities do not establish a player's original class or complete build.

The match dossier separates this match from **previous retained matches**, capped at 80 distinct historical abilities per dossier. The player database has a bounded lifetime ability summary, including observations from pruned matches. Old observations do not establish what is currently equipped. Combat visibility, distance and game restrictions mean many opponent abilities/heals will never be observed. There is no full equipment, traits, enchantments, Champion Point, skill bar, private-statistic or hidden-MMR inspection.

## Storage and maintenance

Defaults: **200 detailed matches**, **10,000 lifetime profiles**, **80 distinct abilities per match participant and lifetime profile**, **24 character aliases per profile**, and **200 retained match references per profile**. History can be set to 10–1000 matches, profiles to 100–20,000. Each active match bounds observation owners at 100 and unmatched-name cache entries at 256. Only summaries are saved, never raw combat events.

Pruning removes old match detail and dangling links, while retaining lifetime encounter/statistic totals and bounded historical abilities. Existing profiles continue updating at the profile limit; new profiles are skipped and the saved scoreboard displays a notice. Reaching an ability limit skips new distinct ability IDs, while already tracked abilities continue aggregating. Lowering the profile limit does not delete existing profiles. Maximum-stat links may refer to a pruned match; the recorded value/date remain. Back up SavedVariables before updates or resets.

Storage schema is separate from ESO's SavedVariables version, which remains fixed at 1 to prevent ESO replacing history on addon updates. Missing known fields are initialized; unrecognized records are retained and omitted from views if structurally invalid. A newer unsupported schema disables initialization rather than overwriting it. No update silently resets all history.

## API verification and known limits

See [docs/API_VERIFICATION.md](docs/API_VERIFICATION.md) for signatures, primary sources, fallbacks and release gates. API 101051 is verified from the repository's current `live` documentation; availability on your installed server/client must be checked in game. Format support is dynamic and has **not** been live-certified for 4v4, 6v6v6 or 9v9.

Known unverified behavior includes cumulative-statistic results for a player who departed an earlier round, the exact delay of final scoreboard updates, complete round-roster retention after reconnection, native font/layout clipping at different resolutions, and how much enemy combat information the client exposes. Scoreboard APIs can return numeric zero for an unsupported/mode-irrelevant counter; the addon cannot distinguish such an API-supplied zero from a genuine zero. It stores nil only when a call/constant/value is absent or invalid. Captured scoreboard damage/healing and observed event damage/healing are intentionally separate.

## Validation

Offline tests run under **Lua 5.1**, with mocked ESO APIs and UI controls:

```powershell
uv pip install lupa
python tests/run.py
```

The test runner explicitly imports `lupa.lua51`. **33 offline scenarios passed during implementation**, and all ten Lua addon files compiled and loaded. Lupa/Python are development-only and are not installed or used by the addon. Tests cover initialization/recovery, deduplication, outcomes including three-team ambiguity, account matching, encounter totals, detail pruning, comparisons, absent values, ability aggregation and limits, multi-round lifecycle, delayed/unstable scoreboards, timeout, reload, early departure, 18-player UI view construction and protected reset. Native drawing and live engine semantics are not mocked faithfully enough to certify gameplay behavior.

In-game acceptance checklist:

- Enable with empty SavedVariables; check `/bgd`, every tab, search, Escape, dragging, scaling, scrollbar, tooltips and all slash commands without Lua errors.
- Complete each available 4v4, 6v6v6 and 9v9 format; compare every captured player/team statistic with the native final scoreboard. Verify team IDs, mode names, objective units, medals, ties and unequal teams.
- Complete a multi-round match. Confirm no save at intermediate `POSTROUND`, one final record, cumulative totals and separate round scores. Test an earlier-round leaver and substitute.
- Observe delayed updates with debug enabled. Confirm no empty/preliminary save, no duplicate on repeated scoreboard updates or `/reloadui`, and useful timeout diagnostics.
- Reload during a round and at the final scoreboard; change local character after a match; disconnect/reconnect; leave early; verify preserved history outside Battlegrounds. Confirm the active match token is reused only while appropriate.
- Encounter known accounts on different characters; verify ally/opponent totals and team results. Exercise missing-account and ambiguous-name cases without merges.
- Check observations against visible combat activity. Confirm ticks increment event counts, pet sources are ignored, missing observations show the empty state and old abilities are clearly historical.
- Compare players with zero deaths and unavailable stats. Test history filters and long/localized names at the lowest supported scale.
- Set a low match limit; verify pruned links and retained lifetime totals. Back up SavedVariables, then test the reset timeout/confirmation.

Build the distributable with `python tools/package.py`. It includes only the addon, README and API notes, under the required addon folder name.
