local B, C = BattlegroundDossier, BattlegroundDossier.Controls
B.UI = { section = "MATCHES", view = "history", sort = "score", descending = true, teamFilter = "All players",
    historyFilter = "All matches", search = "", page = 1, pools = {}, used = {}, y = 0 }
local U = B.UI
local function name(p) return p.character or p.account or "Unknown player" end
local function number(v)
    if type(v) ~= "number" then return "—" end
    if v % 1 ~= 0 then return string.format("%.2f", v) end
    return tostring(v)
end
local function class(p) return p.classId and B.API:Call("GetClassName", GENDER_MALE, p.classId) or "Unknown" end
local function format(m)
    return tostring(m.teamCount or "?") .. " teams • capacity " .. tostring(m.teamCapacity or "?") .. "/team • " .. tostring(m.participantCount or #m.players) .. " recorded"
end
local function localPlayer(m) for _, p in ipairs(m.players) do if p.isLocal then return p end end end
local function matchesSearch(p, query)
    return query == "" or ((B.Normalize(p.character) or ""):find(query, 1, true) or (B.Normalize(p.account) or ""):find(query, 1, true))
end
function U:Initialize()
    local w = WINDOW_MANAGER:CreateTopLevelWindow("BattlegroundDossierWindow")
    self.window = w
    w:SetDimensions(1160, 760); w:SetClampedToScreen(true); w:SetMovable(true); w:SetMouseEnabled(true)
    w:SetHidden(true); w:SetScale(B.db.settings.scale)
    self:Position()
    C:Backdrop(w)
    C:Label(w, "BATTLEGROUND DOSSIER", 24, 15, 900, 38, "ZoFontWinH1"):SetColor(0.82, 0.69, 0.45, 1)
    C:Label(w, "MATCH HISTORY  /  PLAYER ENCOUNTERS  /  OBSERVED COMBAT", 26, 55, 950, 24, "ZoFontGameSmall")
    C:Button(w, "×", 1100, 16, 36, function() self:SetVisible(false) end)
    w:SetHandler("OnMoveStop", function(c) B.db.settings.position = { x = c:GetLeft(), y = c:GetTop() } end)
    SCENE_MANAGER:RegisterTopLevel(w, false)
    for i, section in ipairs({ "MATCHES", "PLAYERS", "STATISTICS", "SETTINGS" }) do
        local target = section
        C:Button(w, section, 24 + (i - 1) * 160, 90, 150, function() self:Open(target) end)
    end
    C:Button(w, "Latest match", 835, 90, 145, function() self:Last() end)
    C:Button(w, "History", 990, 90, 140, function() self:Open("MATCHES") end)
    C:Label(w, "Search players / accounts", 26, 135, 260, 24, "ZoFontGameSmall")
    self.searchBox = C:Search(w, 255, 132, 360, function(text)
        self.search = B.Normalize(text) or ""; self.page = 1
        EVENT_MANAGER:UnregisterForUpdate(B.name .. "Search")
        EVENT_MANAGER:RegisterForUpdate(B.name .. "Search", 180, function()
            EVENT_MANAGER:UnregisterForUpdate(B.name .. "Search"); self:Render(true)
        end)
    end)
    self.filter = C:Button(w, "All matches", 640, 132, 270, function() self:CycleFilter() end)
    C:Tooltip(self.filter, "Click to cycle filters. Scoreboard filters: all, allies, opponents, familiar. History filters include result, format and game mode.")
    self.scroll = C:New(w, nil, "ZO_ScrollContainer")
    self.scroll:SetAnchor(TOPLEFT, w, TOPLEFT, 24, 177)
    self.scroll:SetAnchor(BOTTOMRIGHT, w, BOTTOMRIGHT, -24, -42)
    self.body = self.scroll:GetNamedChild("ScrollChild")
    self.body:SetResizeToFitDescendents(false); self.body:SetDimensions(1088, 500)
    C:Label(w, "Observed activity is partial client-visible evidence. Team results are not duel statistics.", 26, 727, 1100, 24, "ZoFontGameSmall")
    EVENT_MANAGER:RegisterForEvent(B.name .. "UICombat", EVENT_PLAYER_COMBAT_STATE, function(_, combat)
        if combat then self:SetVisible(false) end
    end)
end
function U:SetVisible(visible)
    if visible then SCENE_MANAGER:ShowTopLevel(self.window)
    else
        if self.searchBox then self.searchBox:LoseFocus() end
        SCENE_MANAGER:HideTopLevel(self.window)
    end
end
function U:Position()
    self.window:ClearAnchors()
    local p = B.db.settings.position
    if type(p) == "table" and type(p.x) == "number" and type(p.y) == "number" then
        self.window:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, p.x, p.y)
    else self.window:SetAnchor(CENTER, GuiRoot, CENTER, 0, 0) end
end
-- Reuse controls across views. Rendering is user-driven, never combat-event-driven.
function U:Acquire(kind)
    self.used[kind] = (self.used[kind] or 0) + 1
    self.pools[kind] = self.pools[kind] or {}
    local index = self.used[kind]
    local c = self.pools[kind][index]
    if not c then
        if kind == "label" then c = C:Label(self.body, "", 0, 0, 1080, 28)
        elseif kind == "button" then c = C:Button(self.body, "", 0, 0, 100, function() end)
        else c = C:New(self.body, CT_BACKDROP); c:SetEdgeTexture("", 1, 1, 1, 0) end
        self.pools[kind][index] = c
    end
    c:SetHidden(false); c:ClearAnchors()
    return c
end
function U:Text(text, height, font, color, x, width)
    local c = self:Acquire("label")
    c:SetAnchor(TOPLEFT, self.body, TOPLEFT, x or 8, self.y)
    c:SetDimensions(width or 1070, height or 28); c:SetFont(font or "ZoFontGame"); c:SetText(text)
    c:SetColor(unpack(color or { 0.86, 0.83, 0.76, 1 }))
    self.y = self.y + (height or 28)
    return c
end
function U:Action(text, x, width, callback, y)
    local c = self:Acquire("button"); c:SetAnchor(TOPLEFT, self.body, TOPLEFT, x, y or self.y)
    c:SetDimensions(width, 30); c:SetText(text); c:SetHandler("OnClicked", callback)
    return c
end
function U:Heading(text)
    self.y = self.y + 12
    self:Text(text, 36, "ZoFontHeader3", { 0.82, 0.69, 0.45, 1 })
end
function U:Open(section)
    self.section, self.page, self.profile = section or self.section, 1, nil
    if section == "MATCHES" then self.view = "history" end
    self:SetVisible(true); self:Render()
end
function U:Toggle() if self.window:IsHidden() then self:SetVisible(true); self:Render() else self:SetVisible(false) end end
function U:Last()
    for i = #B.db.matches, 1, -1 do if B.Storage:Valid(B.db.matches[i]) then self:OpenMatch(B.db.matches[i]); return end end
    self:Open("MATCHES")
end
function U:OpenMatch(m)
    self.section, self.view, self.match, self.expanded, self.compareA, self.compareB = "MATCHES", "scoreboard", m, nil, nil, nil
    self:SetVisible(true); self:Render()
end
function U:CycleFilter()
    local choices, current
    if self.section == "MATCHES" and self.view == "scoreboard" then
        choices, current = { "All players", "My team", "Opposing teams", "Familiar players" }, self.teamFilter
    else
        choices, current = { "All matches", "Wins", "Losses", "Draws", "Competitive", "Big Team Battles" }, self.historyFilter
        local modes = {}
        for _, m in ipairs(B.db.matches) do if B.Storage:Valid(m) and m.modeName then modes[m.modeName] = true end end
        local sorted = {}; for mode in pairs(modes) do sorted[#sorted + 1] = mode end; table.sort(sorted)
        for _, mode in ipairs(sorted) do choices[#choices + 1] = "Mode: " .. mode end
    end
    local nextIndex = 1
    for i, item in ipairs(choices) do if item == current then nextIndex = i % #choices + 1 end end
    if self.view == "scoreboard" and self.section == "MATCHES" then self.teamFilter = choices[nextIndex] else self.historyFilter = choices[nextIndex] end
    self.page = 1; self:Render()
end
function U:Render(preserveScroll)
    if not self.body then return end
    for _, pool in pairs(self.pools) do for _, c in ipairs(pool) do c:SetHidden(true) end end
    self.used, self.y = {}, 0
    self.filter:SetHidden(self.section ~= "MATCHES")
    self.filter:SetText(self.view == "scoreboard" and self.teamFilter or self.historyFilter)
    if self.section == "MATCHES" then
        if self.view == "scoreboard" and self.match then self:Scoreboard(self.match) else self:History() end
    elseif self.section == "PLAYERS" then self:Players()
    elseif self.section == "STATISTICS" then self:Statistics()
    else self:Settings() end
    self.body:SetHeight(math.max(500, self.y + 24))
    if not preserveScroll then self.scroll:GetNamedChild("Scroll"):SetVerticalScroll(0) end
end
function U:Pager(count, size)
    local pages = math.max(1, math.ceil(count / size)); self.page = math.min(self.page, pages)
    self:Action("‹ Previous", 8, 130, function() self.page = math.max(1, self.page - 1); self:Render() end)
    self:Action("Next ›", 145, 130, function() self.page = math.min(pages, self.page + 1); self:Render() end)
    self:Action("Page " .. self.page .. " / " .. pages .. " • " .. count .. " records", 300, 650, function() end)
    self.y = self.y + 42
    return (self.page - 1) * size + 1, math.min(count, self.page * size)
end
function U:History()
    self:Heading("RECORDED MATCHES")
    local rows = {}
    for i = #B.db.matches, 1, -1 do
        local m = B.db.matches[i]
        if B.Storage:Valid(m) then
            local f = self.historyFilter
            local accepted = f == "All matches" or f == "Wins" and m.outcome == "Win" or f == "Losses" and m.outcome == "Loss"
                or f == "Draws" and m.outcome == "Draw" or f == "Competitive" and m.competitive == true
                or f == "Big Team Battles" and type(m.teamCapacity) == "number" and m.teamCapacity >= 6
                or f == "Mode: " .. (m.modeName or "")
            local found = self.search == ""
            for _, p in ipairs(m.players) do if matchesSearch(p, self.search) then found = true; break end end
            if accepted and found then rows[#rows + 1] = m end
        end
    end
    if #rows == 0 then self:Text("No recorded matches match these filters. Completed matches will appear here.", 50); return end
    local first, last = self:Pager(#rows, 40)
    for i = first, last do
        local m = rows[i]; local p = localPlayer(m) or {}
        local text = B.DateTime(m.finishedAt) .. " • " .. (m.outcome or "Unresolved") .. " • " .. (m.map or "Unknown map") .. " • " .. (m.modeName or "Unknown mode")
        self:Action(text, 8, 1065, function() self:OpenMatch(m) end); self.y = self.y + 32
        self:Text(format(m) .. "    K/D/A " .. B.Value(p.kills) .. "/" .. B.Value(p.deaths) .. "/" .. B.Value(p.assists) .. "    Damage " .. B.Value(p.damage), 32, "ZoFontGameSmall")
    end
end
local columns = {
    { "PLAYER", "character", 8, 270 }, { "CLASS", "classId", 280, 110 }, { "TEAM", "team", 393, 95 },
    { "K", "kills", 490, 40 }, { "D", "deaths", 532, 40 }, { "A", "assists", 574, 40 },
    { "DAMAGE", "damage", 618, 112 }, { "HEALING", "healing", 732, 112 },
    { "SCORE", "score", 846, 100 }, { "OBJECTIVE", "objective", 948, 132 },
}
function U:Scoreboard(m)
    self:Heading((m.map or "Unknown Battleground") .. "  •  " .. (m.outcome or "Unresolved"))
    self:Text((m.modeName or "Unknown mode") .. "  •  " .. B.DateTime(m.finishedAt) .. "  •  " .. format(m), 30)
    local teams = {}; for id in pairs(m.teams) do teams[#teams + 1] = id end; table.sort(teams)
    local parts = {}
    for _, id in ipairs(teams) do local t = m.teams[id]; parts[#parts + 1] = t.name .. ": " .. B.Value(t.score) .. " (" .. t.result .. ")" end
    self:Text((m.scoreLabel or "Team scores") .. "  •  " .. table.concat(parts, "   |   "), 42)
    self:Text("My team: " .. (m.teams[m.localTeam] and m.teams[m.localTeam].name or "Unknown") .. "   •   Placement by score: " .. B.Value(m.placement), 28)
    if m.rosterMayBeIncomplete then self:Text("Some previously seen participants are absent from the final roster. This record may be incomplete.", 42) end
    if m.profileLimitReached then self:Text("Player database limit reached. Match details were retained; new lifetime profiles were skipped.", 42) end
    if m.hasRounds then self:Text("Cumulative match statistics. Objective aggregate unavailable for mixed-round modes.", 32) end
    if self.compareA and self.compareB then self:Comparison(m) end
    local headerY = self.y
    for _, col in ipairs(columns) do
        local key = col[2]
        local button = self:Action(col[1] .. (self.sort == key and (self.descending and " ↓" or " ↑") or ""), col[3], col[4], function()
            if self.sort == key then self.descending = not self.descending else self.sort, self.descending = key, true end
            self:Render(true)
        end, headerY)
        C:Tooltip(button, key == "objective" and (m.objectiveLabel or "Unavailable for this match") or ("Sort by " .. col[1] .. ". Missing values sort last. Click a player to expand their dossier."))
    end
    self.y = self.y + 38
    local rows = {}
    for _, p in ipairs(m.players) do
        local rel = B.TeamRelation(m, p)
        local accepted = self.teamFilter == "All players" or self.teamFilter == "My team" and rel == "ally"
            or self.teamFilter == "Opposing teams" and rel == "opponent"
            or self.teamFilter == "Familiar players" and (p.previousEncounters or 0) > 0
        if accepted and matchesSearch(p, self.search) then rows[#rows + 1] = p end
    end
    table.sort(rows, function(a, b)
        local x, y = a[self.sort], b[self.sort]
        if x == nil or y == nil then if x ~= y then return x ~= nil end
        elseif x ~= y then if self.descending then return x > y else return x < y end end
        return (B.Identity(a, m.world) or "") < (B.Identity(b, m.world) or "")
    end)
    for _, p in ipairs(rows) do
        local rowY = self.y; local bg = self:Acquire("background")
        bg:SetAnchor(TOPLEFT, self.body, TOPLEFT, 0, rowY); bg:SetDimensions(1084, 34)
        bg:SetCenterColor(p.isLocal and 0.19 or 0.09, p.isLocal and 0.16 or 0.085, 0.065, 0.95)
        local color = B.API:Call("GetBattlegroundTeamColor", p.team)
        if color and color.UnpackRGB then
            local r, g, b = color:UnpackRGB(); bg:SetEdgeColor(r, g, b, 1)
        else bg:SetEdgeColor(0.3, 0.25, 0.17, 1) end
        for _, col in ipairs(columns) do
            local key = col[2]; local text = B.Value(p[key])
            if key == "character" then text = (p.isLocal and "★ " or (p.previousEncounters or 0) > 0 and "◆ " or "") .. name(p)
            elseif key == "classId" then text = class(p)
            elseif key == "team" then text = tostring(p.team) .. (p.team == m.localTeam and " Ally" or " Opp.") end
            if key == "character" then
                local button = self:Action(text, col[3], col[4], function() self.expanded = self.expanded == p and nil or p; self:Render(true) end, rowY + 2)
                C:Tooltip(button, name(p) .. "\n" .. (p.account or "Account unavailable") .. "\nClick to expand dossier")
            else
                self.y = rowY + 4
                local label = self:Text(text, 28, "ZoFontGameSmall", nil, col[3], col[4])
                C:Tooltip(label, text)
            end
        end
        self.y = rowY + 38
        if self.expanded == p then self:Dossier(m, p) end
    end
    if #rows == 0 then self:Text("No players match these filters.", 50) end
    if #m.rounds > 1 then
        self:Heading("ROUND SCORES")
        for r, row in ipairs(m.rounds) do
            local scores = {}; for _, id in ipairs(teams) do scores[#scores + 1] = m.teams[id].name .. " " .. B.Value(row.scores[id]) end
            self:Text("Round " .. r .. " • " .. B.API:ModeName(row.mode) .. " • " .. table.concat(scores, " | "), 32)
        end
    end
end
function U:AbilityList(abilities, title)
    self:Heading(title)
    self:Text("Observed client-visible events, not casts or a complete equipped skill bar. Effects do not prove equipment.", 38, "ZoFontGameSmall")
    local rows = {}; for id, a in pairs(abilities or {}) do rows[#rows + 1] = { id = id, data = a } end
    table.sort(rows, function(a, b)
        local ca, cb = a.data.category or "Other observed effects", b.data.category or "Other observed effects"
        if ca ~= cb then return ca < cb end
        return (a.data.name or "") < (b.data.name or "")
    end)
    if #rows == 0 then self:Text("No reliably attributed observations recorded.", 32); return end
    for _, row in ipairs(rows) do
        local a = row.data
        self:Text((a.name or "Unknown ability") .. " (#" .. row.id .. ") • " .. (a.category or "Other observed effects")
            .. " • " .. B.Value(a.events) .. " events • damage " .. B.Value(a.damage) .. " • healing " .. B.Value(a.healing), 34)
        self:Text("First " .. B.Date(a.firstSeen) .. " • Last " .. B.Date(a.lastSeen), 26, "ZoFontGameSmall")
    end
end
function U:Dossier(m, p)
    self:Heading(name(p) .. "  /  DOSSIER")
    self:Text((p.account or "Account unavailable") .. " • " .. class(p) .. " • " .. B.TeamRelation(m, p) .. " • K/D " .. number(B.Ratio(p)), 30)
    self:Text("K/D is unavailable when deaths are zero or either statistic is missing.", 28, "ZoFontGameSmall")
    self:Action("Select A", 8, 130, function() self.compareA = p; self:Render(true) end)
    self:Action("Select B", 145, 130, function() self.compareB = p; self:Render(true) end)
    self:Action("Compare with me", 285, 220, function() self.compareA, self.compareB = p, localPlayer(m); self:Render() end)
    self.y = self.y + 40
    for _, key in ipairs(B.metrics) do
        local sum, n = 0, 0
        for _, peer in ipairs(m.players) do if peer.team == p.team and type(peer[key]) == "number" then sum, n = sum + peer[key], n + 1 end end
        local avg = n > 0 and sum / n or nil
        local share = type(p[key]) == "number" and sum > 0 and p[key] / sum * 100 or nil
        self:Text(key .. ": " .. number(p[key]) .. "    Team average " .. number(avg) .. "    Share of available team total " .. number(share) .. "%", 28)
    end
    self:Text("Team averages use available entries only. A share of deaths is descriptive, not a positive rating.", 34, "ZoFontGameSmall")
    self:Heading("OTHER SCOREBOARD STATISTICS")
    local keys = {}; for key in pairs(B.API.scoreTypes) do keys[#keys + 1] = key end
    table.sort(keys)
    local details = {}
    for _, key in ipairs(keys) do details[#details + 1] = key .. ": " .. B.Value(p[key]) end
    for i = 1, #details, 3 do self:Text(table.concat(details, "    |    ", i, math.min(i + 2, #details)), 36, "ZoFontGameSmall") end
    for _, medal in pairs(p.medals or {}) do self:Text("Medal: " .. (medal.name or "Unknown") .. " × " .. medal.count, 28) end
    self:Text("Lives remaining at last recorded round: " .. B.Value(p.livesRemaining), 28)
    local profile = B.Players:Get(p, m.world)
    self:Text("Encounters before this match: " .. B.Value(p.previousEncounters) .. ((p.previousEncounters or 0) == 0 and " • First Encounter" or " • Familiar Player"), 32)
    if profile then self:ProfileSummary(profile, m.id) end
    self:AbilityList(p.abilities, "OBSERVED ABILITIES — THIS MATCH")
    -- Derive previous observations from retained matches to avoid labeling this match as historical.
    local previous, previousCount = {}, 0
    local identity = B.Identity(p, m.world)
    for _, old in ipairs(B.db.matches) do
        if B.Storage:Valid(old) and old.id ~= m.id and (old.finishedAt or 0) <= (m.finishedAt or 0) then
            for _, peer in ipairs(old.players) do
                if B.Identity(peer, old.world) == identity then
                    for id, ability in pairs(peer.abilities or {}) do
                        if not previous[id] and previousCount < B.MAX_ABILITIES then
                            previous[id] = B.Copy(ability); previousCount = previousCount + 1
                        elseif previous[id] then
                            previous[id].events = (previous[id].events or 0) + (ability.events or 0)
                            if ability.lastSeen then previous[id].lastSeen = math.max(previous[id].lastSeen or ability.lastSeen, ability.lastSeen) end
                            if ability.firstSeen then previous[id].firstSeen = math.min(previous[id].firstSeen or ability.firstSeen, ability.firstSeen) end
                            for _, key in ipairs({ "damage", "healing" }) do
                                if ability[key] then previous[id][key] = (previous[id][key] or 0) + ability[key] end
                            end
                        end
                    end
                end
            end
        end
    end
    self:AbilityList(previous, "OBSERVED ABILITIES — PREVIOUS RETAINED MATCHES")
    self.y = self.y + 16
end
function U:Comparison(m)
    local a, b = self.compareA, self.compareB
    self:Heading("PLAYER COMPARISON")
    self:Text("A: " .. name(a) .. "     |     B: " .. name(b) .. "     |     Difference: A minus B", 36)
    for _, row in ipairs(B.Compare(a, b)) do self:Text(row.key .. "     A " .. number(row.a) .. "     B " .. number(row.b) .. "     Δ " .. number(row.difference), 28) end
    local pa, pb = B.Players:Get(a, m.world), B.Players:Get(b, m.world)
    self:Text("Lifetime encounters     A " .. B.Value(pa and pa.encounters) .. "     B " .. B.Value(pb and pb.encounters), 30)
    self:Text("Observed unique abilities     A " .. B.Count(a.abilities) .. "     B " .. B.Count(b.abilities), 30)
    self:Action("Clear comparison", 8, 220, function() self.compareA, self.compareB = nil, nil; self:Render() end); self.y = self.y + 36
    self:AbilityList(a.abilities, "A — OBSERVED ABILITIES")
    self:AbilityList(b.abilities, "B — OBSERVED ABILITIES")
end
function U:ProfileSummary(p, excludeId)
    self:Heading(B.Players:Classification(p) .. " • LIFETIME RECORD")
    self:Text("Identity confidence: " .. (p.confidence or "unknown") .. " • Encounters " .. B.Value(p.encounters) .. " • Ally " .. B.Value(p.allies) .. " • Opponent " .. B.Value(p.opponents), 32)
    self:Text("Team results against: " .. B.Value(p.wins) .. " wins / " .. B.Value(p.losses) .. " losses / " .. B.Value(p.draws) .. " draws / " .. B.Value(p.unresolved) .. " unresolved", 32)
    self:Text("First " .. B.Date(p.firstSeen) .. " • Most recent " .. B.Date(p.lastSeen) .. " • Lifetime includes this and subsequently recorded matches.", 34)
    local characters = {}; for _, character in pairs(p.characters or {}) do characters[#characters + 1] = character end; table.sort(characters)
    self:Text("Observed characters: " .. table.concat(characters, ", "), math.max(32, math.ceil(#table.concat(characters, ", ") / 95) * 26))
    local classes = {}; for id in pairs(p.classes or {}) do classes[#classes + 1] = class({ classId = id }) end
    self:Text("Observed classes: " .. table.concat(classes, ", "), 34)
    local bests = {}; for key, best in pairs(p.bests or {}) do bests[#bests + 1] = key .. " " .. B.Value(best.value) end; table.sort(bests)
    for i = 1, #bests, 3 do self:Text("Recorded maximums: " .. table.concat(bests, " | ", i, math.min(i + 2, #bests)), 32) end
    local refs = {}; for _, id in ipairs(p.matches or {}) do refs[id] = true end
    for i = #B.db.matches, 1, -1 do
        local m = B.db.matches[i]
        if B.Storage:Valid(m) and refs[m.id] and m.id ~= excludeId then
            self:Action("Open " .. B.Date(m.finishedAt) .. " • " .. (m.map or "Unknown") .. " • " .. (m.outcome or "Unresolved"), 8, 1060, function() self:OpenMatch(m) end)
            self.y = self.y + 32
        end
    end
end
function U:Players()
    self:Heading("PLAYER INTELLIGENCE")
    if self.profile then
        self:Action("‹ Player database", 8, 250, function() self.profile = nil; self:Render() end); self.y = self.y + 38
        self:Text(self.profile.account or self.profile.latestCharacter or "Unknown player", 36, "ZoFontHeader3")
        self:ProfileSummary(self.profile)
        self:AbilityList(self.profile.abilities, "OBSERVED ABILITIES — LIFETIME (MAY INCLUDE OLD BUILDS)")
        return
    end
    local rows = {}
    for _, p in pairs(B.db.profiles) do
        if type(p) == "table" then
        local found = matchesSearch({ account = p.account, character = p.latestCharacter }, self.search)
        if not found then for _, character in pairs(p.characters or {}) do if matchesSearch({ character = character }, self.search) then found = true; break end end end
        if found then rows[#rows + 1] = p end
        end
    end
    table.sort(rows, function(a, b) if a.encounters ~= b.encounters then return a.encounters > b.encounters end; return a.id < b.id end)
    if #rows == 0 then self:Text("No known players match your search. Complete a Battleground to build your dossier.", 50); return end
    local first, last = self:Pager(#rows, 40)
    for i = first, last do
        local p = rows[i]
        self:Action("◆ " .. (p.account or p.latestCharacter or "Unknown") .. " • " .. p.encounters .. " encounters • " .. B.Players:Classification(p), 8, 1060, function() self.profile = p; self:Render() end)
        self.y = self.y + 36
    end
end
function U:Statistics()
    self:Heading("PERSONAL STATISTICS")
    local s = B.db.stats
    self:Text("Lifetime matches " .. (s.total or 0) .. " • Wins " .. (s.Win or 0) .. " • Losses " .. (s.Loss or 0) .. " • Draws " .. (s.Draw or 0) .. " • Unresolved " .. (s.Unresolved or 0), 38)
    local resolved = (s.Win or 0) + (s.Loss or 0) + (s.Draw or 0)
    self:Text("Win rate (wins / resolved matches, including draws): " .. (resolved > 0 and string.format("%.1f%%", (s.Win or 0) / resolved * 100) or "—"), 32)
    self:Heading("PERSONAL RECORDS — HIGHEST MATCH TOTALS")
    self:Text("Maximum totals are descriptive. More deaths, for example, does not mean a better performance.", 34, "ZoFontGameSmall")
    for _, key in ipairs(B.metrics) do
        local best = (s.bests or {})[key]
        self:Text(key .. ": " .. B.Value(best and best.value) .. (best and " • " .. B.Date(best.timestamp) or ""), 30)
    end
    for _, field in ipairs({ "opponents", "allies" }) do
        self:Heading(field == "opponents" and "MOST FREQUENT OPPONENTS" or "MOST FREQUENT TEAMMATES")
        local rows = {}; for _, p in pairs(B.db.profiles) do if type(p) == "table" and (p[field] or 0) > 0 then rows[#rows + 1] = p end end
        table.sort(rows, function(a, b) if a[field] ~= b[field] then return a[field] > b[field] end; return a.id < b.id end)
        for i = 1, math.min(10, #rows) do
            local p = rows[i]
            self:Action((p.account or p.latestCharacter or "Unknown") .. " • " .. p[field], 8, 1060, function() self.section, self.profile = "PLAYERS", p; self:Render() end)
            self.y = self.y + 32
        end
    end
    self:Heading("RECENT PERFORMANCE TREND")
    self:Text("Most recent 10 versus preceding 10 retained matches. Different modes and formats can affect averages.", 38)
    for _, key in ipairs({ "kills", "deaths", "damage", "healing", "score" }) do
        local sums, counts = { 0, 0 }, { 0, 0 }; local n = 0
        for i = #B.db.matches, 1, -1 do
            local m = B.db.matches[i]
            if B.Storage:Valid(m) then
                n = n + 1; if n > 20 then break end
                local group = n <= 10 and 1 or 2; local p = localPlayer(m)
                if p and type(p[key]) == "number" then sums[group] = sums[group] + p[key]; counts[group] = counts[group] + 1 end
            end
        end
        self:Text(key .. " • recent avg " .. number(counts[1] > 0 and sums[1] / counts[1] or nil)
            .. " • previous avg " .. number(counts[2] > 0 and sums[2] / counts[2] or nil), 30)
    end
end
function U:Settings()
    self:Heading("SETTINGS")
    for _, item in ipairs({ { "autoOpen", "Open final scoreboard automatically" }, { "notifications", "Familiar-player chat notification" },
        { "observeCombat", "Record observed combat abilities" }, { "debug", "Lifecycle debug messages" } }) do
        local key, label = item[1], item[2]
        self:Action((B.db.settings[key] and "[ON] " or "[OFF] ") .. label, 8, 1050, function()
            B.db.settings[key] = not B.db.settings[key]
            if key == "observeCombat" then B.Combat:SetActive(B.API:Call("GetCurrentBattlegroundState") == BATTLEGROUND_STATE_RUNNING) end
            self:Render(true)
        end); self.y = self.y + 40
    end
    for _, item in ipairs({ { "scale", "Window scale", 0.05, 0.6, 1.2 }, { "historyLimit", "Detailed match limit", 50, 10, 1000 },
        { "frequentThreshold", "Frequent player threshold", 1, 2, 100 }, { "profileLimit", "Lifetime profile limit", 1000, 100, 20000 } }) do
        local key, label, step, low, high = unpack(item)
        local function change(delta)
            B.db.settings[key] = math.max(low, math.min(high, B.db.settings[key] + delta))
            if key == "scale" then self.window:SetScale(B.db.settings.scale) end
            if key == "historyLimit" then B.Storage:Prune() end
            self:Render(true)
        end
        self:Action("−", 8, 45, function() change(-step) end)
        self:Action("+", 60, 45, function() change(step) end)
        self.y = self.y + 2; self:Text(label .. ": " .. number(B.db.settings[key]), 38, nil, nil, 125, 900)
    end
    self:Text("Lowering the detailed match limit immediately prunes oldest details. Lifetime encounter totals remain.", 44)
    self:Text("At the profile limit, new profiles are skipped; existing profiles and match records continue updating.", 44)
    self:Action("Center window", 8, 260, function() B.db.settings.position = nil; self:Position() end); self.y = self.y + 42
    self:Heading("HISTORY RESET")
    self:Text("Use /bgd reset, then /bgd reset confirm within 30 seconds. Deletes match details, profiles and aggregates.", 50)
    self:Text("SavedVariables are written by ESO on logout or /reloadui. Back them up before installing addon updates.", 50)
end
